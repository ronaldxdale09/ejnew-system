
 <!-- Bootstrap core JavaScript-->
 <script src="assets/jquery/jquery.min.js"></script>
 <script src="assets/jquery/jquery.js"></script>
 <script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
 <script src="assets/js/chosen.jquery.js"></script>
<script src="assets/js/chosen.jquery.min.js"></script>
