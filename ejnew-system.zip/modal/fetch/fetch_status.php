<?php 
// Include the database config file 
    include('../../function/db.php');

  
   $status = $_SESSION['transaction'];


     echo $status;

?>