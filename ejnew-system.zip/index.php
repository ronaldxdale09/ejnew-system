
<!-- Fantacy Design -->
 
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <title>Login </title>
    <link rel="stylesheet" href="css/login.css">

  </head>
  <body>
    <div class="main">
      <p class="sign" align="center">Login </p>
      <form method='POST' action='function/login.php'>
        <input class="un " type="text" align="center" name='username' placeholder="Username">
        <input class="pass" type="password" align="center" name='password' placeholder="Password">
        <button type='submit' class="submit" align="center">Login</a>
    
 
</form>
      </div>
  </body>
</html>